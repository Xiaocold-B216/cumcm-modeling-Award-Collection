# Current Formal Excerpt — CUMCM-1998-A-007 — source page 1

- Current body: `derived/scale/papers/CUMCM-1998-A-007/paper.md`
- Current body SHA256: `34FFD0C7AF3CCAEA34794C03CC2D9EA755C84976D568974A83B0E6C37C3BE72C`
- Current page segment SHA256: `4B19983960725F4D6D8C715C9A8BCB7B57CAA1B5BBECE11B22640E1441DF692F`
- Extraction method: `STRICT_SOURCE_PAGE_MARKER_BOUNDARY`
- Repair route: `DOC_EXISTING_EXTRACTION_RECONSTRUCTION`
- Repair layer: `G11_MARKER_ONLY_PAGE_LOCAL_FORMAL_BODY`
- Repair page audit: `catalog/scale/g11_multi_route_formal_repair_pages.csv`

The block between the delimiters below is copied from the current `paper.md` substring. No human wording, OCR, rendering, or extraction was added in this stage.

<!-- BEGIN EXACT CURRENT PAPER.MD SUBSTRING -->
<!-- source_page: 1 -->

卷 第

第

年

数学 的实践 与认识

期
入

月

,

招

〕

投 资组合与模 糊规划模 型
王正方

赵文明

倪 德娟

数学建模教 练 组

指导教师

,

杭 州 电子 工业 学院 杭州

流

题

,

本文能针对 间题的要求 通过 分析 建立正 确的数学模型 并 用偏 好 系数加权 法把双 目标 优化 间
,

,

化为单 目标优化 间题

计算得 到 正确的结 果 作 者还 用 模 糊线 胜规 划 的方法 来求 解 进行 比较 此

,

,

外本文还 分析讨 论了头 资额 相对小的情形
摘 要

交

编者按

们

,

本文讨论 了投 资的风 险与收益 的 问题 首先 我们给出了一个比 较 完整 的模型 然后

数额相 当大时的 一个近 似处理模型

,

,

考 虑投资

,

用偏好系数加权法和 模糊线性 规划法进 行 了求解 接 下来
杯卜另叮
,

,

研

我 们又 考虑 了如何处理 投 资额相对 较小的情 况 下的最优投资组合情况 引入 了绝对 收 益率进 行 了较为有

效 的解决
、

问颐的提出 略

：
科

一

二

、

基本 假设 略

三

、‘

投 资者 拥 有 的全部 资金

供 投 资者选 择的资产
、
购 买资 产
要付交 易费费率
’ 同期银 行 利率
其余符 号在文 中陆续 引出

、
的平 均 收益率
资产
的风 险损 失率
购买 资产

投资 于 资金 的 比例

公
众

二‘

符号说 明

号

对

、

尸

四

、

,

问题的分 析和模型 的建立

设 银行 存款也是 等价于 市场 上 供投 资者选择 的资产之一 存银 行 记 为 叼。 而 它相应 的风 险损失率
。

和 交易 费

尸。

信

设投资于 第

,

存银行 生 息与投 资市场上 的资产可 以 统一处 理
种资产所付 交易费为 八
… 的

均为

经 以 上 变换

,

,

,

戈二 尸

,

少
、
戈

几
以
,
认

,

,

, ,

,

,

,

,‘,

,,

微

其中

,,,
。
‘, ,
, ,

,

。
,‘
二
如 投 资 则在 八八 与
上式 中 如不投 资 于 ’ 则
可得 人
两者 中取大 的 一个
后再乘 以 相应的 交 易费率即为所付 的交易费 这 完全 符合 了 实际要 求
,

,

,

,

,

,

然

,

投 资 总额 刀 可分 为两 部分

共为 皿 八 川
之二 日

显 然有 又 魂
,

门

一 部分用 来付 交易费共为 冗 八

兄 刀 二 二 盯 而 投资
日

』

另一 部分则 可 用来购 买 各种资产

相应 的净收益 月

兄

·

, 、

八了, ,

又八
艺

‘
<!-- END EXACT CURRENT PAPER.MD SUBSTRING -->
