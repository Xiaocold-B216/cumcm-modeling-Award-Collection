# Current Formal Excerpt — CUMCM-2001-A-001 — source page 1

- Current body: `derived/scale/papers/CUMCM-2001-A-001/paper.md`
- Current body SHA256: `25E382CD5CE4F99D69F070B726A4A72EB33EDE0E295075941C1F42856F80AC3E`
- Current page segment SHA256: `4A6C44C2E278119C4B0383F75AB481F51F0F5FA179D3C396EAA68691CD621104`
- Extraction method: `STRICT_SOURCE_PAGE_MARKER_BOUNDARY`
- Repair route: `DOC_EXISTING_EXTRACTION_RECONSTRUCTION`
- Repair layer: `G11_MARKER_ONLY_PAGE_LOCAL_FORMAL_BODY`
- Repair page audit: `catalog/scale/g11_multi_route_formal_repair_pages.csv`

The block between the delimiters below is copied from the current `paper.md` substring. No human wording, OCR, rendering, or extraction was added in this stage.

<!-- BEGIN EXACT CURRENT PAPER.MD SUBSTRING -->
<!-- source_page: 1 -->

维普资讯 http://www.cqvip.com

第 ｌ９卷

工

建模 专 辑

２００２年 ０２月

程

数

学

学

报

Ｖ ｏｌ １９ Ｓｕｐｐ

ＪＯＵ ＲＮＡＬ ＯＦ ＥＮ ＧＩ
Ｎ ＥＥＲ Ｉ
Ｎ Ｇ Ｍ ＡＴ ＨＥＭ ＡＴ Ｉ
ＣＳ

Ｆｅｂ ２００２

文章 编 号 ：
１００５—
３０８５（２００２）
０５—
００４１—
０６

血 管切 片的三维 重 建
柳 海东 ， 陈

璐， 江

浩

指导 教师 ： 卢钦 和
（苏 州 大 学 ．苏 州 ２１５００６）
编 者按 ：
本 文指 出在 一定 的条 件下 ．
血 管 中 轴 线 与 截 面 曲 交 点 必 落 在 截 面 边 界 上 的一 时 点 的 连 线 的 中 点 上 ．
过这 对 点 的截 面

项 式 拙台 得到 中 轴线 方程

文 章 用 多 种 方 法 对 建 立 的模 型 进 行 了桂 驻 ．
这是 本文 的 主要扰 点 之一

要：
本 文讨论 血 管 的三维 重建 问题 。我们 通 过研究 ．
证 明了 以下 的定理
定理

设 ｃ（ｉ）是 中 轴 线 和 平 面 ｚ ： ｉ的 查 点 、那 么 存 在 以 ｃ（ｉ）为 中 点 且 端 点 Ｐ】
“ ） Ｐ２（ｉ
）在 ａ （ｔ）
上 的线 段 并 且

在 Ｐｌ
（

．

尸２（ｉ）处

交

摘

流

边 界的 两条 切线 是相 互 平行 的 。据 此 ，
设 计 出相应 的算 法 ．
计 算结 果 比较精 确 。在 求得 中轴 线 的离 散点 后 进行 了 多

（ｔ）的 切 线 相 互 平 行 。

，

研

根据 定 理 ，
我 们 拽 到 利 甩 求 截 面 腰 象 边 界 曲 线 的 平 行 切 线 方 法 找 到 中 轴 线 和 １００十 截 面 的 交 点 及 管 道 的 直 径 ５９
１２３８ｐｉ
ｘ
ｅ［ 并 用 这 １００十 交 点 的 数 据 拟 台 出 中 轴 线 的 方 程 ：
（ｆ）＝

０ ２０７８０６—０ ６１
０３０３ｃ ０ ２０６４５５ｃ —０ ０１４４９３５￡

：
科

＋０ ０００５１７７７４ｔ‘一 ８ ３９４２４１９７７７５４０４７ｘ ｌ０一
十 ６ １３３３５３１１２０３５９７５× ｌ０

ｔ 一 １ ６６７３２１８２６７４４４８０５× ｌ０一 ｒ

（ｔ）＝ １５８ ２１ｌ＋ ｌ ８６５９５ｃ一０ ２６６７９８

＋０ ０１
４１４０７ｆ’

一

０．０００３２５４１２ｔ‘＋ ３ ０４３２７５５９７６８０８０７ｘ ｌ０一

一

９ ８９９１７１２７４６１５０６３× ｌ０

（ｃ）： ｔ

’

ｔ

面

号

然后 我 们用 中轴 线 的方 程重 建 了三 雄血 管 ．
井 求 出 了重 建 血 管 在 ４０十 平 面 上 的 截 面

（３０≤ ≤ ６９）．
井 与原 始截

“（
３０≤ ｉ
≤ ６９）
进 行 比较 ．
截 面 平 均 符 音 率 高 选 ９６ ８０２４ 。

差蹙词 ｝
切 线 ；多 项 式 拟 台 ；
模 型检 验

众

分 类 号 ：ＡＭ Ｓ（２００Ｏ）０５Ｄ１
７

中 呵 分 粪 号 ：０２４２ １

文 蕾 标 识 码 ：Ａ

公

１ 问 题 重 述 （略 ）
２ 模 型假 设

信

１） 不 考 虑 血 管 的 弹 性 ，
将 血 管视 为 一 类 特 殊 的管 道 ，其 表 面 由球 心 沿 某 一 曲线 （称 为 中

轴 线 ）且 半 径 固定 的 球 滚 动 包 络 而成

微

２） 管 道 中轴 线 与 每 张 切 片 有 且 只 有 一个 交 点 。
３） 切 片 间 距 以及 图 象 象 素 的 尺 寸均 为 １，
可 将 切 片 图象 视 为 平 面 图形 。
●

４） 中轴线充分光滑且它每一点的曲率Ｋ（）
较小（
ｉ丰 ＞Ｒ，
Ｒ为管道半径）。
<!-- END EXACT CURRENT PAPER.MD SUBSTRING -->
