# Current Formal Excerpt — CUMCM-2002-B-005 — source page 4

- Current body: `derived/scale/papers/CUMCM-2002-B-005/paper.md`
- Current body SHA256: `28F3388B2889E9ABCBDDB342B37A2816BC36EFE30A7725B7D6C78ECBBD250502`
- Current page segment SHA256: `47E0FFA95AFF7FCECFF78CDE5099AD4AC867DA1F811315807DF213FD886967D6`
- Extraction method: `STRICT_SOURCE_PAGE_MARKER_BOUNDARY`
- Repair route: `DOC_EXISTING_EXTRACTION_RECONSTRUCTION`
- Repair layer: `G11_MARKER_ONLY_PAGE_LOCAL_FORMAL_BODY`
- Repair page audit: `catalog/scale/g11_multi_route_formal_repair_pages.csv`

The block between the delimiters below is copied from the current `paper.md` substring. No human wording, OCR, rendering, or extraction was added in this stage.

<!-- BEGIN EXACT CURRENT PAPER.MD SUBSTRING -->
<!-- source_page: 4 -->

维普资讯 http://www.cqvip.com

工

二

一

程

数

学

二
ｌ

ｎＰ

学

报

第 ２０卷

（ ： １，
２，
３）
’ ’

’、…
，

ｒ。（１一 （１一 Ｐ。） ） ＝ ｒ
：（１一 （１一 Ｐ：） ） ＝ ｒ
ｓ（１一 （１一 Ｐｓ） ）
ｒＩ ＋ ｒ２ ＋ ｒ３ ＝ １

则 Ｐ。。＋Ｐ：：＋Ｐ。。＝（
１一ｓ
）
∑ ｒ［
１一（
１一Ｐ）］
（
当 凡是定值时，
其值是常数）
。
‘＝ Ｉ

３

以ｄ
。＝Ⅱ （
Ｐｉ）反映了高项将的公平程度，
此时当且仅当Ｐｔ－：Ｐ：：＝Ｐｓｓ时ｄ－
＝

ｌ

７

最大。
同理 ｄ
：＝Ⅱ （
Ｐｋ ）也反映了低项奖的公平程度。
我们可取 ｄ＝ｄ
－
ｄ
：可作为衡量公
Ｉ＝ ４

平程 度 的 数 学 表 达 式 ，
但 由于 Ｐ

远 小 于 １，
所 以 ｄ很 小 ，
设

＝ ｄ ×７，
记 为 总公 平 因子 。

流

３．
４博 彩 心 理 的 因素 分 析

彩 民 的 兴趣 大 小 与 单 注 收 益 率 、
公 平 度 相 关 。对 一 个 方 案 ，彩 民 的 看 法 主 要 是 由收 益 决
定的 ，
我 们 用 这 个 量 的某 个 函数 来 衡 量 该 方 案 的彩 民 的 吸 引力 ，
而 彩 民 的看 法 是一 个 心 理 因

交

素，
是 一 个 很 难 准 确 衡 量 的 量 。根 据 心 理 学 的 知 识 ，
人 的 心 理 因 素 的 变 化 可 用 博 彩 心 理 函数

来近似刻画 ，
博 彩 心 理 与 单 注 的 收益 率 有关 ，因此 ，
取 博 彩 心 理 函数 为

研

Ｗ（ｔ） ＝ １一 ｅ一

４

：
科

其中 ｔ：ＥＩ ｌ，
ｎ表示销售注数。
模 型 的建 立 与 求解

综合 以上的分析 ，
我们 用 影 响方 案 合 理 性 的三 个 因子 ：收 益 期 望 ，公 平 因 素 ，博 彩 因 素 ，
来 构 造 给定 方 案 合 理 性 的评 判 函 数 ，
并 且 通 过 求 解 这 个 函数 的值 来 判 定 各 方 案 的优 劣 。

号

４．１评 价 函数 的 构 造 （第 一 问 的 解 答 ）

方 案 的 吸 引 力 函数 ， ＝ 博 彩 因子 ＊ 公 平 因 子 ，即
， ＝ Ｗ（ｔ）×／
ｌ ＝ （１一 ｅ一 ）×／
ｌ
３

７

众

７

３

ｔ＝∑ Ｐｋ ＋∑ ｒ（
１一（
１一Ｐ））一∑ Ｐｋ ∑ ｒ（
１一（
１一Ｐ）
“
）
Ｉ。 ４

Ｉ＝４

ｉ＝ １

×７

公

：

ｉ＝ １

根 据 彩 票 目前 每 期 开 奖 的有 关 资 料 ，以及 题 目中 对 单 注 一 等 奖 奖 金 的 约 束 ，
取彩票销售

信

注 数 ｎ ＝ ２００万 注 进 行 计 算 。
以 ２９个 方 案 的有 关 数 据 代 人 判 别 函数 厂中 ，
求 出 厂的值 ，通 过 比较 厂值 的 大 小 ，
我们可 以
．

．

．

确 定 给 定 的各 种 方 案 的 优 劣 。

微

由此 得 到 对 ２９个 方 案 的 排 序 为

９，
５，１１，
８，
７，１９，
２０，１６，
２４，１０，
６，
２２，１８，２５，１２，
２６，
１３，１４，
２３，１５，１７，
２１，
２９，
２，
２７，
３，
２８ ，
４，
１

４．
２第 二 问 的 模 型 及 解 答

由问 题 一 的求 解 结 果 可 以看 出 ，
传统 型 和无 特 别 号 （
２３号 ）的方 案 已 不 可 能列 入 最 优 方
案 中 ，因此 ，
问题 二 中 只需 在 乐 透 型彩 票 的两 种 方 案 （Ｍ／Ｎ 和

＋１／
Ⅳ）进 行 讨 论 ，我 们 需 要
<!-- END EXACT CURRENT PAPER.MD SUBSTRING -->
