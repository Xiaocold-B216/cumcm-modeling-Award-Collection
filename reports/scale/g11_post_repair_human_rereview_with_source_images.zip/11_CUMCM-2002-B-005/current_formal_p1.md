# Current Formal Excerpt — CUMCM-2002-B-005 — source page 1

- Current body: `derived/scale/papers/CUMCM-2002-B-005/paper.md`
- Current body SHA256: `28F3388B2889E9ABCBDDB342B37A2816BC36EFE30A7725B7D6C78ECBBD250502`
- Current page segment SHA256: `911C5A1368413DC50E7A66A815441B879E7FE00E5322E8AE94F6730EBD00135D`
- Extraction method: `STRICT_SOURCE_PAGE_MARKER_BOUNDARY`
- Repair route: `DOC_EXISTING_EXTRACTION_RECONSTRUCTION`
- Repair layer: `G11_MARKER_ONLY_PAGE_LOCAL_FORMAL_BODY`
- Repair page audit: `catalog/scale/g11_multi_route_formal_repair_pages.csv`

The block between the delimiters below is copied from the current `paper.md` substring. No human wording, OCR, rendering, or extraction was added in this stage.

<!-- BEGIN EXACT CURRENT PAPER.MD SUBSTRING -->
<!-- source_page: 1 -->

Ｉ ｉ

ｌ

｛

；

｛

｛

第 ２ｏ卷

●

ｉ

；

｛

，

；

Ｉ

工

第 ５期

２００３年 Ｏ３月

；

：

，

程

．

；

数

＾

学

；

－ ．

学

ｌ＾

＾

，，＾

｝

｛｝

４

ｌ

；

报

｛

维普资讯 http://www.cqvip.com
，

々

ｊ

ｔ

Ｖ０１．２０ Ｎｏ．５
Ｍ ａｒ． ２０ｏ３

ＪＯＵＲＮＡＬ ＯＦ ＥＮＧＩ
ＮＥＥＲＩ
ＮＧ ＭＡＴＨＥＭＡＴＩ
ＣＳ

文章编号 ：
１
００５．
３０８５（２００３）
０５。
００８１。
０７

彩 票 中 的数 学
李 英 雄 ， 郭松 海 ， 康
指导教师 ： 蔡吉花

陈 兴元

慧
母 丽华

流

（黑 龙 江 科 技 学 院 ，哈尔 滨 １
５０００１）
编 者 按 ：本 文 考 虑 了单 注 收 益 率 、
彩 民 心 理 因 素 、彩 票 设 置 公 平 度 等 因 素 ，
尽 管 量 化 这 些 因 素 不 一 定 恰 如 其 分 ，但 以这 些
因素构 造判 别 函数 还是 合理 的 ，
文章 据此 判定现 行 方案 的优劣 ，
规 划出更 优 的方 案 。正如 文章 的讨 论所 述所得

交

优 化 方 案 与 销 售 额 有 关 是 一 个 大 缺 陷 。 数 模 竞 赛 多 年 来 均 提 出 要 注 意 摘 要 的 质 量 。 今 年 的 Ｂ题 要 求 作 者 给 报
纸 写一 篇论文 供彩 民参 考 ，
本 文 的 短 文 是 一 篇 不 错 的文 章 、写 摘 要 和 短 文 的 能 力 是 竞 赛 要 求 的 ，
对科 技工作 人员
也 是非 常重要 的 ，
但今 年竞赛 论 文在这方 面仍 有很 多问题 ，
许 多短文 并没 有为 彩民提 供恰 当 的信息 ，
正确认识 和

研

分 析彩票 活动 。

摘

要 ：本 模 型 讨 论 的 是 如 何 评 判 传 统 型 彩 票 和 乐 透 型 彩 票 的一 般 评 奖 方 案 的 合 理 性 问 题 。 本 文 首 先 根 据 彩 票 中奖 规

：
科

则，
利用 古典 概率 求 出 了这两 种类 型 彩票 的各种 奖项 出现 的可能 性 。把每 注 彩票 中奖 与否 看成 贝努 利试验 ，
在
假设 每期 彩票 的销 售量 足够 多的前 提下 ，
由贝努 利大数 定律 归结 为 正态 分布 ，
从 而 求 出 了 每 注 彩 票 的平 均 收 益
率 。在此 基础 上 ，
结 合公 平尺 度 ，
利用 彩 民的博彩 心理 因素构造 了评 判方 案 合理 性 的判 别 函数 ，
利 用 ＭＡＴＬＡＢ６．
１软 件 编 程 计 算 ，
判 别 出 题 目所 给 方 案 的 奖 金 设 置 的 优 劣 ，
并 且利用 这个 判别 函 数 ，
我 们 建立 了求解 最优 方案 的
非线性 规 划模 型。通 过求 解所 建立 的模型 ，
找 到 在 给 定 销 售 注 数 下 最 优 方 案 及 奖 项 和 奖 金 额 的设 置 。
关 键 词 ：彩 票 ；
二项 分布 ；
期望 收益 率 ；
判 别 函数
分 类 号 ：ＡＭＳ（２０
００）９
０Ｃ０５

中 图分 类 号 ：Ｏ２２１．
１

文 献 标 识 码 ：Ａ

号

｝

１ 问题 的重 述 （
略）

众

；

２ 模 型 的 假 设及 符号 说 明
２．
１模 型 的假 设

１）每 注 彩 票 只兑 付 最 高 奖 级 奖 金 ，
不可兼得 ；

公

｝

２）假 设 彩 票 的规 则 是 以公 平 合 理 为 原 则 ；
３）假 设 彩 票 的发 行 费 用 不 计 ，彩 票 总 奖金 比例 一 般 为销 售 总 金 额 的 ５０％ ；

信

ｌ

４）假 设 高 项 奖按 事 先 设 定 的 百 分 比分 配 ，
且 按 当 期 各 奖 级 实 际 中 奖 注数 平 均 分 配 该 奖

级；

微

；

５）奖 金 取 决 于 当期 彩 票 投 注 额 的 多 少 ，
投注额越多 ，
奖金越高 ；
６）假 设 彩 民大 都 具 有 博 彩 心 理 。
２．
２符 号 说 明

ｅ

｛

｛

｛

；

ｔ：｛
<!-- END EXACT CURRENT PAPER.MD SUBSTRING -->
