# Current Formal Excerpt — CUMCM-2020-D-003 — source page 135

- Current body: `derived/scale/papers/CUMCM-2020-D-003/paper.md`
- Current body SHA256: `90CA9CFE4E538A72291F2133FDF3A1B289BC8F88EC983F7DA9BB458BB1D7F559`
- Current page segment SHA256: `9C7DE9A9E6208E89C1D4560EFF2028B3FCE0DDFCD1A8212874914F9925BEB804`
- Extraction method: `Q3_EXISTING_PAGE_TEXT_ANCHORED_CURRENT_PAPER_WINDOW`
- Repair route: `Q3_SELECTIVE_PAGE_OCR_REPAIR`
- Repair layer: `Q3_OCR_PAGE`
- Repair page audit: `catalog/scale/g11_multi_route_formal_repair_pages.csv`

The block between the delimiters below is copied from the current `paper.md` substring. No human wording, OCR, rendering, or extraction was added in this stage.

<!-- BEGIN EXACT CURRENT PAPER.MD SUBSTRING -->
EiaE 风月 机 回 呈 NS wase % 旋转 ca= cos(pi/2+pi/2+pi/2) sa=sin(pi/2+pi/2+pi/2) A = [ca-sasacal: X= [9:1); 9(.2)T; Y = AX; 2Y= Y(L)+al0(1); Y(2,)-a10(1)+a10(2)+al0(L): f ”rr OA ay AN 步 % 绘图 SN plot(Y(L,), Y(2.), LineWidth 2) 所 title( 工 件 2 完整 轮廓 线 修正 后 图 小 SS 工件 2 完整 轮廓 线 修正 司 钨 N 2 -4 -6 -8 -10 -12 -14 -16 I ( 8 ABR Wa 5 0 5 10 15 135
<!-- END EXACT CURRENT PAPER.MD SUBSTRING -->
