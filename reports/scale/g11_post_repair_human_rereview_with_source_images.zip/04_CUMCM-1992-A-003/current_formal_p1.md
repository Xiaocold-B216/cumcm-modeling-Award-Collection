# Current Formal Excerpt — CUMCM-1992-A-003 — source page 1

- Current body: `derived/scale/papers/CUMCM-1992-A-003/paper.md`
- Current body SHA256: `B537B4905E726561A593EFECC57A16E22F7923DAED30A910BB1BFB28A545DEFC`
- Current page segment SHA256: `B2937750CB38BE36928CA66529893F931ADA2BFC66169507FE52229E219ED403`
- Extraction method: `STRICT_SOURCE_PAGE_MARKER_BOUNDARY`
- Repair route: `DOC_EXISTING_EXTRACTION_RECONSTRUCTION`
- Repair layer: `G11_MARKER_ONLY_PAGE_LOCAL_FORMAL_BODY`
- Repair page audit: `catalog/scale/g11_multi_route_formal_repair_pages.csv`

The block between the delimiters below is copied from the current `paper.md` substring. No human wording, OCR, rendering, or extraction was added in this stage.

<!-- BEGIN EXACT CURRENT PAPER.MD SUBSTRING -->
<!-- source_page: 1 -->

“

”

关 于 非 线 性 交 调 的 频 率 设 计 的 评注

— 题

的 解答 和 有 关情 况

谢 衷 洁
北 京 大学 概率统计 系

功

流

加

问题 的 背景

题 是 一 道 关 于 非 线 性 交 调 的 频 率 设 计 问 题 其 工 程 背 景 广 泛 存 在 于 通 信 系统 中 例
如 人 造 卫 星 通 信 中 的 频 率 配 置 问题 就 与 本 题 有 关

众所 周 知 人造 卫星转 发 器 的能 源 大
,

,

的

,

弱

因 而 功 率 是 非常 有 限 的

,

而行 波 管 放 大 器 的 输 人 输 出 关 系 便 是 非 线 性

,

研

多依 赖 于 太 阳 能

倘 若 要 求 工 作 在 线 性 区 域 内 则 会 使 本 来 功 率 就 非 常 有 限 的 放 大 器 的 输 出信 号 更 加 微
因 此 为 了 获 得 最 大 的 输 出功 率 就 要 克 服 工 作 在 非 线 性 区 域 内带 来 的 许 多 问题 其 中
,

、

非 线 性 器件 输人
,

则

。

‘

：
科

之 一 就 是 由非 线 性 幅 度 相位 引 出的 交 扰 调 制
矿

二

,

今

,

的 展 式 中不 仅 包 含 有原 信 号 频 率

率 成分 称 为交调

如 果 这 些 交 调 出现 在

,

中 的一 项 任 务就 是 在 允许 的 范 围 内调 整

九

,

阶 都 需分析

工 程设 计

使 得 各 交 调 对信 号 不 构 成 干 扰

、

信

在

允 许的 范 围内

,

,

微

交 调 只 考虑

阶 一

一

由所 给 的 数 据 建 立

关系式

在 满 足 频 率 约 束 条 件 下 解 出全 部 可 能 的 配

计 算 输 出的 信 号 频 率 和 交 调 频 率 的 系 数 振 幅

的频 率设计

或 者是

本题 的 一 种 参 考 答 案

,

置

,

将 复 杂 的 输 人 输 出特 性 加 以 简 化

本 题 可 以 有 多 种 解 法 但 归 纳 起 来 要经 三 个 步 骤

输 人 输 出关 系 式

而且包 含有

,

频 率 只 考 虑 整数 解 等 等

二

,

“

的 接 收 带 内就会 形 成 干 扰

,

信 号 个 数 减 到 三 个 一 段 数 十 个或 上 百 个

公
众

阶

,

设想对

简称交 调

等新 的频

本 题 就 是 上 述 通 信 工 程 中频率 设 计 问题 的 简化
也 不 考虑 相位 非 线 性

,

土

和

和

,

,

而 输 人 输 出关 系 为

,

号

弱千 扰

般

交

,

计算各信噪 比

,

选 出合乎 本 题 要 求

、

此 外 根 据 竞赛 的 要 求 还 应 对 本 结 果 的 稳 定 性 优 缺 点 及 推 广 等 方 面 进 行 一
,

些 合 理 的 讨论
以下 是 本 题 的 参 考 性 的 一 种 答 案 因 为在 不 同 的 假 设 条件 下 本 题 还 可 以 有 不 同 的解
,

,

答
卜

关系

关系的建立

由题 意 只 考 虑

最 简单 的 是 用 回归方 法

阶 交调 已 暗示 可 用

有 的 组 的 做 法是

的 关 系式

然 而 所 给 的数 据 中 有

阶 多项 式 进 行 回归
“ ,

十
“

先用

,

,

阶 多项 式 来 拟 合 卜

一

表 明常 数项

,

得

,

。

一

史 为 台理

因而 应
<!-- END EXACT CURRENT PAPER.MD SUBSTRING -->
